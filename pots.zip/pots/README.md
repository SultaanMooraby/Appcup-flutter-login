# Beautiful Login Page In Flutter With Reminder-Me Functionality

Create a login and signup page With Reminder-Me in flutter.

This amazing app is provided in open source. So, helpful contributions are highly appreciated.

## ScreenShots


| <img src="screenshots/login.jpg"  width="300"/> | <img src="screenshots/registerr.jpg" width="300"/>  |

---

### :heart: Found this project useful?

If you found this project useful, then please consider giving it a :star: on Github and sharing it with your friends via social media.

---

## Project Created & Maintained By

### Anurag Anand


<a href="https://www.linkedin.com/in/anurag-anand-a51625273/"><img src="https://github.com/aritraroy/social-icons/blob/master/linkedin-icon.png?raw=true" width="60"></a>
<a href="https://www.instagram.com/aanurag_ssingh/"><img src="https://github.com/aritraroy/social-icons/blob/master/instagram-icon.png?raw=true" width="60"></a>



## Getting Started

This project is a starting point for a Flutter application.

- clone repo and setup dart plugin


